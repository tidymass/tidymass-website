globalVariables(names = c(
  "log10_p",
  "log2_fc",
  "marker",
  "na_freq",
  "correlation",
  "from",
  "ht_opt",
  "node",
  "p_adjust",
  "p_value",
  "use",
  "v"
))
