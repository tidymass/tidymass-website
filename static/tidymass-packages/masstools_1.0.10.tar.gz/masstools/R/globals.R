utils::globalVariables(
    names = c(
        "Exp.intensity",
        "Exp.mz",
        "Lib.intensity",
        "Lib.mz",
        "intensity",
        "mz",
        "variable_id",
        "sample_id",
        "value",
        ".",
        "name"
    )
)
