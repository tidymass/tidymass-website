
#' @title match_table
#'
#' @description match_table
#'
#' @name match_table
#' @aliases match_table
#' @docType data
#' @keywords data
#' @examples
#' data(match_table)
NA


#' @title smpdb_primary_pathway_id
#'
#' @description smpdb_primary_pathway_id
#'
#' @name smpdb_primary_pathway_id
#' @aliases smpdb_primary_pathway_id
#' @docType data
#' @keywords data
#' @examples
#' data(smpdb_primary_pathway_id)
NA
