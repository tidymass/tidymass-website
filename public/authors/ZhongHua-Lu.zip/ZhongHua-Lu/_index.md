---
organizations:
- name: Xiamen University
  role: PhD Candidate
last_name: Lu
social:
- icon: gmail
  # icon_pack: fab
  # link: zhonghua723@gmail.com
superuser: false
title: ZhongHua Lu
user_groups:
- contributors
---





