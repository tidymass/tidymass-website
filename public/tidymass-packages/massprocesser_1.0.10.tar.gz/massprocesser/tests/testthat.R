library(testthat)
library(massprocesser)

test_check("massprocesser")
