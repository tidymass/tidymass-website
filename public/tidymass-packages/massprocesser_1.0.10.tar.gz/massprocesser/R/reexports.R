##' @importFrom magrittr %>%
##' @export
magrittr::`%>%`