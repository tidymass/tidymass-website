# match_compound_name <-
#   function(compound_name1,
#            compound_name2) {
#     
#   }